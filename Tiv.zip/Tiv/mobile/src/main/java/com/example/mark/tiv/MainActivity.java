package com.example.mark.tiv;

import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


            new GetQuestion().execute();



    }

    private String TAG = MainActivity.class.getSimpleName();


    private class GetQuestion extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this, "Json Data is downloading", Toast.LENGTH_LONG).show();

        }

        protected void myFunction() {
            Log.e(TAG, "test");
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            myFunction();
            HttpHandler sh = new HttpHandler();
            // Making a request to url and getting response
            String url = "http://jservice.io/api/random";
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {

                    JSONArray jsonObj = new JSONArray(jsonStr);

                    JSONObject c = jsonObj.getJSONObject(0);

                    final String question = c.getString("question");
                    final String answer = c.getString("answer");


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            final TextView QuestionTextView = (TextView) findViewById(com.example.mark.tiv.R.id.questionText);
                            QuestionTextView.setText(question.toString());

                            final TextView AnswerTextView = (TextView) findViewById(com.example.mark.tiv.R.id.answerText);

                            new CountDownTimer(7000, 1000) {

                                public void onTick(long millisUntilFinished) {
                                    AnswerTextView.setText("Seconds remaining: " + millisUntilFinished / 1000);
                                }

                                public void onFinish() {
                                    AnswerTextView.setText(answer.toString());
                                }

                            }.start();


                        }
                    });


                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });

                }

            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }




        }


}
